package com.fluxmovies.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = Color.Transparent, contentColor = Color.White) { App() }
            }
        }
    }
}

private val LANGS = listOf(
    "All" to "", "English" to "english", "Hindi" to "hindi", "Spanish" to "spanish",
    "French" to "french", "German" to "german", "Italian" to "italian",
    "Russian" to "russian", "Japanese" to "japanese", "Chinese" to "chinese",
    "Arabic" to "arabic", "Portuguese" to "portuguese"
)

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<Movie?>(null) }
    var offline by remember { mutableStateOf<File?>(null) }

    FluxBackground {
        when {
            playing != null -> {
                BackHandler { playing = null }
                PlayerScreen(playing!!.title, playing!!.id, null) { playing = null }
            }
            offline != null -> {
                BackHandler { offline = null }
                PlayerScreen(offline!!.nameWithoutExtension, null, offline) { offline = null }
            }
            else -> {
                if (tab == 0) BrowseScreen { playing = it } else DownloadsScreen { offline = it }
                FloatingNav(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
            }
        }
    }
}

@Composable
fun BrowseScreen(onOpen: (Movie) -> Unit) {
    var query by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf("") }
    var movies by remember { mutableStateOf<List<Movie>>(emptyList()) }
    var page by remember { mutableIntStateOf(1) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var endReached by remember { mutableStateOf(false) }

    LaunchedEffect(query, lang, page) {
        loading = true; error = null
        try {
            val r = withContext(Dispatchers.IO) { Api.search(query, lang, page) }
            movies = if (page == 1) r else movies + r
            endReached = r.size < 30
        } catch (e: Exception) { error = e.message ?: "Network error" }
        loading = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Flux Movies",
            modifier = Modifier.padding(start = 20.dp, top = 14.dp, end = 20.dp, bottom = 10.dp),
            fontSize = 34.sp, fontWeight = FontWeight.Bold
        )
        Box(Modifier.padding(horizontal = 16.dp)) {
            GlassSearch(query) { query = it; page = 1 }
        }
        Spacer(Modifier.height(12.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(LANGS) { (label, code) ->
                GlassChip(label, lang == code) { lang = code; page = 1 }
            }
        }
        error?.let { Text("⚠ $it", Modifier.padding(16.dp), color = Color(0xFFFF6B6B)) }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Color.White, trackColor = Color.Transparent)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(140.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(movies) { i, m ->
                if (i == movies.lastIndex && !loading && !endReached) LaunchedEffect(m.id) { page++ }
                val shape = RoundedCornerShape(22.dp)
                Box(
                    Modifier.fillMaxWidth().aspectRatio(2f / 3f).glass(shape).clickable { onOpen(m) }
                ) {
                    AsyncImage(m.thumb, m.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(
                        Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                            .padding(start = 10.dp, end = 10.dp, top = 28.dp, bottom = 10.dp)
                    ) {
                        Column {
                            Text(m.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (m.year.isNotBlank()) Text(m.year, fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadsScreen(onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf(listOf<File>()) }
    LaunchedEffect(Unit) {
        files = ctx.getExternalFilesDir("Movies")?.listFiles()?.filter { it.length() > 0 }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            "Downloads",
            modifier = Modifier.padding(start = 20.dp, top = 14.dp, end = 20.dp, bottom = 10.dp),
            fontSize = 34.sp, fontWeight = FontWeight.Bold
        )
        if (files.isEmpty()) Text("No downloads yet.", Modifier.padding(20.dp), color = Color.White.copy(alpha = 0.7f))
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(files) { f ->
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp), 0.25f).clickable { onOpen(f) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.nameWithoutExtension, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text("${f.length() / 1024 / 1024} MB", fontSize = 12.sp, color = Color.White.copy(alpha = 0.65f))
                    }
                    IconButton({ f.delete(); files = files - f }) { Icon(Icons.Rounded.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(title: String, id: String?, localFile: File?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("resume", Context.MODE_PRIVATE) }
    val player = remember { ExoPlayer.Builder(ctx).build() }
    var files by remember { mutableStateOf<List<VFile>>(emptyList()) }
    var subs by remember { mutableStateOf<List<Sub>>(emptyList()) }
    var selected by remember { mutableStateOf<VFile?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    fun play(url: String, key: String, withSubs: Boolean, startAt: Long? = null) {
        val b = MediaItem.Builder().setUri(url)
        if (withSubs) b.setSubtitleConfigurations(subs.map {
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url))
                .setMimeType(if (it.name.endsWith(".srt", true)) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT)
                .setLabel(it.name.substringBeforeLast('.'))
                .build()
        })
        player.setMediaItem(b.build(), startAt ?: prefs.getLong(key, 0L))
        player.prepare(); player.playWhenReady = true
    }

    LaunchedEffect(id, localFile) {
        if (localFile != null) {
            play(Uri.fromFile(localFile).toString(), localFile.name, false)
        } else if (id != null) {
            try {
                val (v, s) = withContext(Dispatchers.IO) { Api.files(id) }
                files = v; subs = s
                if (v.isEmpty()) error = "No playable file found for this movie"
                else { selected = v.first(); play(v.first().url, id + v.first().name, true) }
            } catch (e: Exception) { error = e.message }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            val key = if (localFile != null) localFile.name else (id ?: "") + (selected?.name ?: "")
            if (player.duration > 0 && player.currentPosition < player.duration - 10_000) prefs.edit().putLong(key, player.currentPosition).apply()
            player.release()
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassCircleButton(Icons.Rounded.ArrowBackIosNew, "Back", onBack)
            Spacer(Modifier.width(12.dp))
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; useController = true } },
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(24.dp))
        )
        error?.let { Text("⚠ $it", Modifier.padding(16.dp), color = Color(0xFFFF6B6B)) }
        if (files.isNotEmpty()) {
            Text("Quality / version", Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.navigationBarsPadding()
            ) {
                items(files) { f ->
                    Row(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp), 0.25f).clickable {
                            val pos = player.currentPosition
                            selected = f; play(f.url, id + f.name, true, pos)
                        }.padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(if (selected == f) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null)
                        Spacer(Modifier.width(12.dp))
                        Text(f.label, Modifier.weight(1f), fontSize = 14.sp)
                        IconButton({
                            val safe = (title + "_" + f.name.substringAfterLast('/')).replace(Regex("[^A-Za-z0-9._ -]"), "_")
                            val req = DownloadManager.Request(Uri.parse(f.url))
                                .setTitle(title)
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalFilesDir(ctx, "Movies", safe)
                            (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                            Toast.makeText(ctx, "Download started", Toast.LENGTH_SHORT).show()
                        }) { Icon(Icons.Rounded.Download, "Download") }
                    }
                }
            }
        }
    }
}
