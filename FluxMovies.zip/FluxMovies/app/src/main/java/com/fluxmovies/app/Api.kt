package com.fluxmovies.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

data class Movie(val id: String, val title: String, val year: String, val lang: String) {
    val thumb get() = "https://archive.org/services/img/$id"
}

data class VFile(val label: String, val url: String, val name: String, val sizeMb: Long)
data class Sub(val url: String, val name: String)

object Api {
    private val client = OkHttpClient()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String): String =
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            r.body!!.string()
        }

    /** Internet Archive "feature_films" collection: public domain / freely distributable films. */
    fun search(query: String, lang: String, page: Int): List<Movie> {
        var q = "collection:(feature_films) AND mediatype:(movies)"
        if (query.isNotBlank()) q += " AND title:(${query.trim().replace("\"", "")}*)"
        if (lang.isNotBlank()) q += " AND language:($lang)"
        val url = "https://archive.org/advancedsearch.php?q=${enc(q)}" +
            "&fl[]=identifier&fl[]=title&fl[]=year&fl[]=language" +
            "&sort[]=${enc("downloads desc")}&rows=30&page=$page&output=json"
        val docs = JSONObject(get(url)).getJSONObject("response").getJSONArray("docs")
        return (0 until docs.length()).map {
            val d = docs.getJSONObject(it)
            Movie(
                d.getString("identifier"),
                d.optString("title", d.getString("identifier")),
                d.optString("year", ""),
                d.optString("language", "")
            )
        }
    }

    fun files(id: String): Pair<List<VFile>, List<Sub>> {
        val arr = JSONObject(get("https://archive.org/metadata/$id")).optJSONArray("files")
            ?: return emptyList<VFile>() to emptyList()
        val videos = mutableListOf<VFile>()
        val subs = mutableListOf<Sub>()
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            val name = f.getString("name")
            val lower = name.lowercase()
            val url = "https://archive.org/download/$id/" + name.split("/").joinToString("/") { enc(it).replace("+", "%20") }
            val mb = f.optString("size", "0").toLongOrNull()?.div(1024 * 1024) ?: 0
            when {
                lower.endsWith(".mp4") || lower.endsWith(".webm") || lower.endsWith(".ogv") || lower.endsWith(".mkv") -> {
                    val fmt = f.optString("format", lower.substringAfterLast('.'))
                    videos += VFile("$fmt • ${mb}MB", url, name, mb)
                }
                lower.endsWith(".vtt") || lower.endsWith(".srt") -> subs += Sub(url, name)
            }
        }
        // Prefer mp4 (ExoPlayer-friendly), biggest first = highest quality first
        val sorted = videos.sortedWith(compareByDescending<VFile> { it.name.lowercase().endsWith(".mp4") }.thenByDescending { it.sizeMb })
        return sorted to subs
    }
}
